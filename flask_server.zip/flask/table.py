import os
from flask import Flask, render_template

APP = Flask(__name__)
HOST = "0.0.0.0"
PORT = 5000
SERVICE_NAME = "application"
ADMIN_NAME = os.environ.get("ADMIN_NAME", "admin")


@APP.route("/brigada7")
def create_table():
    return render_template("index.html")



if __name__ == "__main__":
    APP.run(host=HOST, port=PORT)
